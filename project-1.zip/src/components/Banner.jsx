import react from "react";


function Banner(){
    return(
        <div className="container p-5  mb-5">
            <h1 className="text-center">World Map</h1>
            <img src="https://geology.com/world/world-map.gif" alt="" />
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cumque ipsa, accusantium laudantium quas esse quo earum? Optio, accusantium! Maiores praesentium commodi adipisci modi accusamus aspernatur error illum nam dolorum, asperiores a ullam incidunt laudantium non recusandae autem fugit sequi, rem, provident aliquam? Nobis, ipsa aperiam? Obcaecati maiores nesciunt omnis velit?</p>
        </div>
    );
}
export default Banner;