
import Card from "./components/Card";
import Navbar from "./components/Navbar";
import Banner from "././components/Banner";
import img from "./Images/ireland.jpg"
import img1 from "./Images/india.jpg"
import img2 from "./Images/aus.jpg"
import img3 from "./Images/new_zealand.gif"



function App() {
  return (
    <>
      <Navbar />
      <Banner />
      <div className="container mt-5">
        <div className="row col-xl-12">
          <div className="col-md-3" >
            <Card img={img1}/>
          </div>
          <div className="col-md-3">
            <Card img={img}/>
          </div>
          <div className="col-md-3">
            <Card img={img2}/>
          </div>
          <div className="col-md-3">
            <Card img={img3}/>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
